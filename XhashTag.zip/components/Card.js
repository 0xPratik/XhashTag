import {Box,Text,Heading} from "@chakra-ui/react"

export default function Card() {
    return (
        <Box w="20rem" h="30rem" bg="black">
            <Text>Card</Text>
        </Box>
    )
}
